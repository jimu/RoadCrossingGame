﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Car : MonoBehaviour
{
    public float speed;
    public Vector3 startPos;
    public Vector3 endPos;

    void Update ()
    {
        // move to the end position
        transform.position = Vector3.MoveTowards(transform.position, endPos, speed * Time.deltaTime);

        // are we at the end position?
        // if so - teleport to the start
        if(transform.position == endPos)
        {
            transform.position = startPos;
        }
    }

    private void OnTriggerEnter2D (Collider2D collision)
    {
        // did we hit the player?
        if(collision.CompareTag("Player"))
        {
            collision.GetComponent<Player>().GameOver();
        }
    }
}