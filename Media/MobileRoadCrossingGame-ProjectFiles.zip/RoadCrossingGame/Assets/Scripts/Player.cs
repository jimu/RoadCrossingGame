﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    public float moveSpeed;
    public int edgeDistance;
    private Vector3 targetPos;
    public int score;

    void Start ()
    {
        targetPos = transform.position;
    }

    // called when we swipe up, left or right
    public void Move (Vector3 moveDirection)
    {
        // if we're at the edge of the screen - return
        if(Mathf.Abs(targetPos.x + moveDirection.x) > edgeDistance)
        {
            return;
        }

        targetPos += moveDirection;
    }

    private void Update()
    {
        transform.position = Vector3.MoveTowards(transform.position, targetPos, moveSpeed * Time.deltaTime);
    }

    // called when we collect a coin
    public void AddScore (int amount)
    {
        score += amount;
        UI.instance.UpdateScoreText(score);
    }

    // called when hit by a car
    public void GameOver ()
    {
        UI.instance.SetEndScreen(false);
    }

    // called when we reach the end goal
    public void Win ()
    {
        UI.instance.SetEndScreen(true);
    }
}